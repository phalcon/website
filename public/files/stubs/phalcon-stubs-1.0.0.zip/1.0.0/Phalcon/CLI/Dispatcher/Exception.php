<?php 

namespace Phalcon\CLI\Dispatcher {

	/**
	 * Phalcon\CLI\Dispatcher\Exception
	 *
	 * Exceptions thrown in Phalcon\CLI\Dispatcher will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
