<?php

class Users extends Phalcon_Model_Base {

}
