<?php 

namespace Phalcon\Validation {

	/**
	 * Phalcon\Validation\Exception
	 *
	 * Exceptions thrown in Phalcon\Validation\* classes will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
