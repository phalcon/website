<?php 

namespace Phalcon\Assets {

	/**
	 * Phalcon\DI\Exception
	 *
	 * Exceptions thrown in Phalcon\Assets will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
