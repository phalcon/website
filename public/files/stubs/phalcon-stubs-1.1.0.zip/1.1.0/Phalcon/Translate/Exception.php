<?php 

namespace Phalcon\Translate {

	/**
	 * Phalcon\Translate\Exception
	 *
	 * Class for exceptions thrown by Phalcon\Translate
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
