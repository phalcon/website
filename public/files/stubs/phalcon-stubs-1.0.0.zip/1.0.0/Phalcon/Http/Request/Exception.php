<?php 

namespace Phalcon\Http\Request {

	/**
	 * Phalcon\Http\Request\Exception
	 *
	 * Exceptions thrown in Phalcon\Http\Request will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
