<?php 

namespace Phalcon\Http\Response {

	/**
	 * Phalcon\Http\Response\Exception
	 *
	 * Exceptions thrown in Phalcon\Http\Response will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
