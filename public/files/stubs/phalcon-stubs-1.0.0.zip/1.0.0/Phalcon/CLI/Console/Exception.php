<?php 

namespace Phalcon\CLI\Console {

	/**
	 * Phalcon\CLI\Console\Exception
	 *
	 * Exceptions thrown in Phalcon\CLI\Console will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
