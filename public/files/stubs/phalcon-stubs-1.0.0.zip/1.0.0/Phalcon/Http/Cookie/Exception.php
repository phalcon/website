<?php 

namespace Phalcon\Http\Cookie {

	/**
	 * Phalcon\Http\Cookie\Exception
	 *
	 * Exceptions thrown in Phalcon\Http\Cookie will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
