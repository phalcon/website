<?php 

namespace Phalcon\Crypt {

	/**
	 * Phalcon\Escaper\Crypt
	 *
	 * Exceptions thrown in Phalcon\Crypt use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
