<?php 

namespace Phalcon\CLI\Router {

	/**
	 * Phalcon\CLI\Router\Exception
	 *
	 * Exceptions thrown in Phalcon\CLI\Router will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
