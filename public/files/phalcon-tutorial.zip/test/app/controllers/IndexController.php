<?php

class IndexController extends Phalcon_Controller {

	function indexAction(){

	}

}
