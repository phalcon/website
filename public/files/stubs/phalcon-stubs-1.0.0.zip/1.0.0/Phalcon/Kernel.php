<?php 

namespace Phalcon {

	class Kernel {

		public static function preComputeHashKey($arrKey){ }

	}
}
