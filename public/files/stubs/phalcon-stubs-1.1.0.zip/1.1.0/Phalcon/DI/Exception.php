<?php 

namespace Phalcon\DI {

	/**
	 * Phalcon\DI\Exception
	 *
	 * Exceptions thrown in Phalcon\DI will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
