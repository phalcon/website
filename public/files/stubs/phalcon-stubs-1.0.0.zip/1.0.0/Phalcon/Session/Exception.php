<?php 

namespace Phalcon\Session {

	/**
	 * Phalcon\Session\Exception
	 *
	 * Exceptions thrown in Phalcon\Session will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
