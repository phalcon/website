<?php 

namespace Phalcon {

	/**
	 * Phalcon\Exception
	 *
	 * All framework exceptions should use or extend this exception
	 */
	
	class Exception extends \Exception {
	}
}
