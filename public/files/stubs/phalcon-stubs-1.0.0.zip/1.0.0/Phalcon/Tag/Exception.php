<?php 

namespace Phalcon\Tag {

	/**
	 * Phalcon\Tag\Exception
	 *
	 * Exceptions thrown in Phalcon\Tag will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
