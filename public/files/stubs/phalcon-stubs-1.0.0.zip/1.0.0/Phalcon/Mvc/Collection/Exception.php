<?php 

namespace Phalcon\Mvc\Collection {

	/**
	 * Phalcon\Mvc\Collection\Exception
	 *
	 * Exceptions thrown in Phalcon\Mvc\Collection\* classes will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception {
	}
}
